# KR Easy Extension para Android

Aplicativo Android em Trusted Web Activity para publicação na Google Play.

- Package ID: `com.kenueferreira.kreasyextension`
- Versão inicial: `1.0.0` (`versionCode 1`)
- URL inicial: `https://kr-easy-extension.vercel.app/mobile.html`
- SDK alvo: Android 36

O arquivo de assinatura não pertence ao repositório. Para compilar a versão de
produção, use a chave privada de upload preservada pelo proprietário do projeto.

Depois de ativar o Google Play App Signing, acrescente também a impressão digital
do certificado de assinatura da Play Store ao arquivo
`/.well-known/assetlinks.json`, sem remover a impressão digital da chave de upload.

KR Easy Extension - chave de upload da Google Play

Pacote Android: com.kenueferreira.kreasyextension
Alias: kr-easy-upload
Senha do arquivo e da chave: KREasy!2026#PlayStore

IMPORTANTE:
- Guarde este arquivo junto com kr-easy-upload.keystore.
- Nunca publique esses dois arquivos no GitHub.
- Eles serao necessarios para assinar as proximas atualizacoes do aplicativo.
- Ative o Google Play App Signing ao criar o aplicativo no Play Console.
